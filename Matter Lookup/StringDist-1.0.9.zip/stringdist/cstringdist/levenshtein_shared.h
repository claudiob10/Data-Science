// Copyright (c) 2017 Oleg Bulkin
// MIT License (https://opensource.org/licenses/MIT)

// Needed prototype
int levenshtein_compute(
    Py_UNICODE *source,
    Py_UNICODE *target,
    int s_len,
    int t_len,
    int rd_flag
);

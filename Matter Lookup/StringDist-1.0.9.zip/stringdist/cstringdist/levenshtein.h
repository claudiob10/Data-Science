// Copyright (c) 2017 Oleg Bulkin
// MIT License (https://opensource.org/licenses/MIT)

// Needed prototypes
PyObject *levenshtein(PyObject *self, PyObject *args);
PyObject *levenshtein_norm(PyObject *self, PyObject *args);
